﻿namespace GrapesTl.Models.Admin;
public class ModuleAssign
{
    public string ModuleId { get; set; }
    public string ModuleName { get; set; }
    public string Link { get; set; }
    public string Icon { get; set; }
    //public IEnumerable<AdMenu> Menu { get; set; }

}