﻿namespace GrapesTl.Models.Admin;


public class Remarks
{
    public string RemarksId { get; set; }
    public string Particulars { get; set; }
}