﻿namespace GrapesTl.Models.Admin;


public class QueryExecute
{

    public string QueryId { get; set; }
    public string Query { get; set; }
    public string EmployeeId { get; set; }

}
