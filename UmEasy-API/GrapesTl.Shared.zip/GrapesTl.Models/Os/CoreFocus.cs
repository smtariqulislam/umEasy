﻿namespace GrapesTl.Models;

public class CoreFocus
{
    public long CoreFocusId { get; set; }
    public string PurposeCause { get; set; }
    public string Description { get; set; }
    public string OurNiche { get; set; }

    public long FileId { get; set; }


}
