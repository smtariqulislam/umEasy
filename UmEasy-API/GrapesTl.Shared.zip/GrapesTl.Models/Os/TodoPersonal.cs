﻿using System;
namespace GrapesTl.Models;

public class TodoPersonal
{

    public string TodoId { get; set; }
    public string Title { get; set; }
    public string Note { get; set; }
    public DateTime DueDate { get; set; }

}
