﻿namespace GrapesTl.Models;

public class TractionOneYearPlanGoal
{
    public long GoalId { get; set; }
    public string Goal { get; set; }
    public long FileId { get; set; }
}
