﻿namespace GrapesTl.Models;

public class CoreValue
{
    public long CoreValueId { get; set; }
    public string CoreValueName { get; set; }
    public long FileId { get; set; }


}
