﻿namespace GrapesTl.Models;

public class TractionIssuesList
{
    public string IssuesListId { get; set; }
    public string FileId { get; set; }
    public string Issue1 { get; set; }
    public string Issue1Assignee { get; set; }
    public string Issue2 { get; set; }
    public string Issue2Assignee { get; set; }
    public string Issue3 { get; set; }
    public string Issue3Assignee { get; set; }
    public string Issue4 { get; set; }
    public string Issue4Assignee { get; set; }
    public string Issue5 { get; set; }
    public string Issue5Assignee { get; set; }
    public string Issue6 { get; set; }
    public string Issue6Assignee { get; set; }
    public string Issue7 { get; set; }
    public string Issue7Assignee { get; set; }
    public string Issue8 { get; set; }
    public string Issue8Assignee { get; set; }



}
