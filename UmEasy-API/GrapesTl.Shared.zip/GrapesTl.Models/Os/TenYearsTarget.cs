﻿namespace GrapesTl.Models;

public class TenYearsTarget
{
    public string TenYearsTargetId { get; set; }
    public string TenYearsTargetName { get; set; }
    public string Note { get; set; }
    public string FileId { get; set; }


}
