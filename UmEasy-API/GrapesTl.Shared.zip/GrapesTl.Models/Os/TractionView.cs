﻿using System;
namespace GrapesTl.Models;

public class TractionView
{
    public string RocksId { get; set; }
    public string FileId { get; set; }
    public DateTime FutureDate { get; set; }
    public string Revenue { get; set; }
    public string Profit { get; set; }
    public string Measurables { get; set; }
    public string Rock1 { get; set; }
    public string Rock1Owner { get; set; }
    public string Rock2 { get; set; }
    public string Rock2Owner { get; set; }
    public string Rock3 { get; set; }
    public string Rock3Owner { get; set; }
    public string Rock4 { get; set; }
    public string Rock4Owner { get; set; }
    public string Rock5 { get; set; }
    public string Rock5Owner { get; set; }
    public string Rock6 { get; set; }
    public string Rock6Owner { get; set; }
    public string Rock7 { get; set; }
    public string Rock7Owner { get; set; }
    public string Rock8 { get; set; }
    public string Rock8Owner { get; set; }



}
