﻿namespace GrapesTl.Models;

public class Role
{
    public string Name { get; set; }
}
