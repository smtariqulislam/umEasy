﻿using GrapesTl.Models;

namespace GrapesTl.Service;

public interface IUserOtpRepository : IRepositoryAsync<UserOtp>
{

}
