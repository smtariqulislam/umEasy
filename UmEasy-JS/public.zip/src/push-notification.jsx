// export const askForPermissionToReceiveNotifications = async () => {
//   try {
//     // const messaging = firebase.messaging();
//     // await messaging.requestPermission();
//     // const token = await messaging.getToken();
//     // konsole.log("Your token is:", token);
//     // return token;
//   } catch (error) {
//     console.error(error);
//   }
// };
