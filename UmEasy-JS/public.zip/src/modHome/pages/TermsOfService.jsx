import React from "react";

const TermsOfService = () => {
  return (
    <>
      <div></div>
    </>
  );
};

export default TermsOfService;
