import React from "react";

const CustomAgenda = () => {
  return <div>CostomAgenda</div>;
};

export default CustomAgenda;
