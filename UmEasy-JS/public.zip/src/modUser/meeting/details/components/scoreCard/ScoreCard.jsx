import React from "react";

const ScoreCard = () => {
  return (
    <div>
      <h1 className="text-xl lg:text-xl font-bold lg:text-semibold text-gray-600 capitalize">
        ScorCard Upcomming
      </h1>
    </div>
  );
};

export default ScoreCard;
