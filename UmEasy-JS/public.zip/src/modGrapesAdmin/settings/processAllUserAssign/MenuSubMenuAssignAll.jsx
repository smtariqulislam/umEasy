import React from "react";
import TopHeader from "../../../components/TopHeader";

const MenuSubMenuAssignAll = () => {
  return (
    <div className="card w-full max-w-screen-xl">
      <TopHeader title="Menu SubMenu Assign" />
      {/* <ProcessAssignButton /> */}
    </div>
  );
};

export default MenuSubMenuAssignAll;
